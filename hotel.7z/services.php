<? include('header.php'); ?>

<div class="wrap">
	<div class="container">
		<div class="services">
			<div class="bread"><a href='index.php'>Главная</a>&nbsp; &nbsp; / &nbsp; &nbsp;<a
					href='services.php'>Услуги</a>
			</div>
			<div class="bread-title">
				<div class="bread-title_text">Услуги</div>
				<div class="bread-title_line"></div>
			</div>
			<div class="services-content">
				<div class="services-content-items">
					<div class="services-content-item">
						<div class="services-content-img"><img src="img/services/bar.jpg" alt=""></div>
						<a href='' class="services-content-name">Бар</a>
						<div class="services-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
					<div class="services-content-item">
						<div class="services-content-img"><img src="img/services/events.jpg" alt=""></div>
						<a href='' class="services-content-name">Мероприятия</a>
						<div class="services-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
					<div class="services-content-item">
						<div class="services-content-img"><img src="img/services/park.jpg" alt=""></div>
						<a href='' class="services-content-name">Парк</a>
						<div class="services-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
					<div class="services-content-item">
						<div class="services-content-img"><img src="img/services/relax.jpg" alt=""></div>
						<a href='' class="services-content-name">Отдых</a>
						<div class="services-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
					<div class="services-content-item">
						<div class="services-content-img"><img src="img/services/restaurant.jpg" alt=""></div>
						<a href='' class="services-content-name">Ресторан</a>
						<div class="services-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
					<div class="services-content-item">
						<div class="services-content-img"><img src="img/services/spa.jpg" alt=""></div>
						<a href='' class="services-content-name">Спа</a>
						<div class="services-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<? include('footer.php'); ?>