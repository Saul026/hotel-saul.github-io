	</div>
</div>
<footer class='footer'>
	<div class="nav-wrap_2">
		<div class="wrap">
			<div class="container">
				<div class="nav_2">
					<div class="footer-nav_text">
						<a href='' class="nav-content_yalta nav-item-links">Отели Ялты</a>
						<a href='' class="nav-content_rooms&price nav-item-links">Номера и цены</a>
						<a href='' class="nav-content_spec nav-item-links">Спецпредложения</a>
						<a href='' class="nav-content_contacts nav-item-links">Контакты</a>
					</div>
					<div class="footer-nav-social">
						<div class="footer-nav-content">Смотри, обсуждай, делись!</div>
						<div class="social">
							<div class="social-items">
								<a class="social-items_vk"><img src="img/footer/vk.png" alt="" class='social-item'></a>
								<a class="social-items_tg"><img src="img/footer/tg.png" alt="" class='social-item'></a>
								<a class="social-items_yt"><img src="img/footer/youtube.png" alt=""
										class='social-item'></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="nav-wrap_1">
		<div class="wrap">
			<div class="container">
				<div class="nav_1">
					<div class="nav-text">
						<div class="footer-nav_text ">Ялта. Отели Ялты: гостиницы в Крыму</div>
					</div>
					<div class="nav-content" style>
						<div class="nav-content_png nav-item " style="background-image: url(img/header-png/phone.png)">
						</div>
						<div class="nav-content_nomber nav-item">+ 7 (978) 888 97 28</div>
						<div class="nav-content_png nav-item" style="background-image: url(img/header-png/email.png)">
						</div>
						<div class="nav-content_email nav-item">srp@hotel-oreanda.ru</div>
						<div class="nav-content_png nav-item" style="background-image: url(img/header-png/search.png)">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>
</body>

</html>