<? include('header.php'); ?>

<div style="background-image: url(img/header.jpg)" class='header'>
  <div class="header-content">
    <div class="header-content_title">Гостиница "Ореанда"</div>
    <div class="header-content_line"></div>
    <div class="header-content_text">Lorem ipsum dolor sit amet consectetur adipisicing elit. </div>
    <button class="header-content_button">Забронировать номер</button>
  </div>
</div>

<div class="wrap">
  <div class="container">
    <div class="index">
      <div class="index-content">
        <div class="index-content-items">
          <div class="index-content_item">
            <div class="index-items_container">
              <img src="img/catalog/bed.png" alt="" class="index-items_img" />
              <p class='index-items_text'>Комфортабельные номера</p>
            </div>
          </div>
          <div class="index-content_item">
            <div class="index-items_container">
              <img src="img/catalog/piggy.png" alt="" class="index-items_img" />
              <p class='index-items_text'>Доступные цены</p>
            </div>
          </div>
          <div class="index-content_item">
            <div class="index-items_container">
              <img src="img/catalog/clipboard.png" alt="" class="index-items_img" />
              <p class='index-items_text'>Широкий спектр услуг</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<? include('footer.php'); ?>