<? include('header.php'); ?>

<div class="wrap">
	<div class="container">
		<div class="rooms">
			<div class="bread"><a href='index.php'>Главная</a>&nbsp; &nbsp; / &nbsp; &nbsp;<a
					href='rooms.php'>Номера</a>
			</div>
			<div class="bread-title">
				<div class="bread-title_text">Номера</div>
				<div class="bread-title_line"></div>
			</div>
			<div class="rooms-img" style='background-image: url(img/room.jpg);'></div>
			<a href='rooms-full.php' class="catalog-items_button ">Забронировать</a>
			<div class="rooms-text">Комфортабельный однокомнатный номер 32 м² с видом на горы/город или парк прекрасно
				подходит для отдыха как двоих человек, так и семьи с ребенком. В номере одна большая кровать 220х200 см
				или две кровати 110х200 см, диван с журнальным столиком. Стоимость указана за размещение одного
				человека. Есть возможность дополнительного размещения.</div>
		</div>
	</div>
</div>

<? include('footer.php'); ?>