<? include('header.php'); ?>

<div class="wrap">
	<div class="container">
		<div class="price">
			<div class="bread"><a href='index.php'>Главная</a>&nbsp; &nbsp; / &nbsp; &nbsp;<a
					href='contacts.php'>Контакты</a>
			</div>
			<div class="bread-title">
				<div class="bread-title_text">Контакты</div>
				<div class="bread-title_line"></div>
			</div>
			<div class="bread-title-price">
				<div class="bread-title-price_text ">Адрес офиса</div>
				<div class="bread-title_line"></div>
				<div class="contacts-text">
					<p>Набережная им. Ленина, 35/2, Ялта Республика Крым, 298635 Россия
					</p>
				</div>
			</div>
			<div class="bread-title-price">
				<div class="bread-title-price_text ">Email</div>
				<div class="bread-title_line"></div>
				<div class="contacts-text"><a href="">srp@hotel-oreanda.ru</a></div>
			</div>
			<div class="bread-title-price">
				<div class="bread-title-price_text ">Телефон</div>
				<div class="bread-title_line"></div>
				<div class="contacts-text"><a href="">+ 7 (978) 888 97 28</a></div>
			</div>
			<div class="bread-title-price">
				<div class="bread-title-price_text ">Схема проезда</div>
				<div class="bread-title_line"></div>
				<div class="contacts-text" style="position:relative;overflow:hidden;"><a
						href="https://yandex.ru/maps/11470/yalta/?utm_medium=mapframe&utm_source=maps"
						style="color:#eee;font-size:12px;position:absolute;top:0px;">Ялта</a><a
						href="https://yandex.ru/maps/11470/yalta/?from=mapframe&ll=34.161665%2C44.489238&mode=usermaps&source=mapframe&um=constructor%3A51d63881f59589be506564140bc9f10364a793f39e191e7ca704910d61f22cf5&utm_medium=mapframe&utm_source=maps&z=15"
						style="color:#eee;font-size:12px;position:absolute;top:14px;">Яндекс Карты — транспорт,
						навигация, поиск мест</a><iframe
						src="https://yandex.ru/map-widget/v1/?from=mapframe&ll=34.161665%2C44.489238&mode=usermaps&source=mapframe&um=constructor%3A51d63881f59589be506564140bc9f10364a793f39e191e7ca704910d61f22cf5&utm_source=mapframe&z=15"
						width="1400" height="400" frameborder="1" allowfullscreen="true"
						style="position:relative;"></iframe></div>
			</div>
		</div>
	</div>
</div>


<? include('footer.php'); ?>