<? include('header.php'); ?>

<div class="wrap">
	<div class="container">
		<div class="about">
			<div class="bread"><a href='index.php'>Главная</a>&nbsp; &nbsp; / &nbsp; &nbsp;<a href='about.php'>о
					нас</a></div>
			<div class="bread-title">
				<div class="bread-title_text">О нас</div>
				<div class="bread-title_line"></div>
			</div>
			<div class="about-content">
				<div class="about-content_img" style="background-image: url(img/about.jpg)"></div>
				<div class="about-content-text">
					<h1 class='about-content-text_title'>Лучший отель 5 звезд в Ялте</h1>
					<p class='about-content-text_paragraph'>Выбирайте лучшие гостиницы и отели Ялты 5 звезд все
						включено: Гостиница входит в топ-5 лучших
						пятизвездочных отелей Ялты в рейтинге TripAdvisor, первая линия у моря, на набережной Ялты: к
						Вашим услугам лучший отель в Ялте 5 звезд!</p>
					<p class='about-content-text_paragraph'>Белоснежный дворец с бежевыми маркизами, расположенный прямо
						на набережной Ялты, будто перенесен
						на Ялтинский променад с картинки модного курорта французской Ривьеры. Этот шедевр арт-нуво,
						спрятанный в зелени пальм и магнолий – легендарный «Ореанда» Премьер Отель — популярный курорт,
						уже более 100 лет визитная карточка Ялты.</p>
					<p class='about-content-text_paragraph'>«Ореанда» распахнула свои двери для гостей в 1907 году и с
						тех пор считалась лучшим отелем в
						городе. Сохранив атмосферу буржуазного прошлого и Ялты эпохи императоров Романовых, сейчас
						«Ореанда» Премьер Отель предлагает гостям отдых класса люкс в современном понимании. В отеле
						есть все для того, чтобы наслаждаться настоящим отдыхом — «dolce farniente» или хорошо
						повеселиться.
					</p class='about-content-text_paragraph'>
				</div>
			</div>
		</div>
	</div>
</div>

<? include('footer.php'); ?>