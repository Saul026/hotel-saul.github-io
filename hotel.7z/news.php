<? include('header.php'); ?>

<div class="wrap">
	<div class="container">
		<div class="news">
			<div class="bread"><a href='index.php'>Главная</a>&nbsp; &nbsp; / &nbsp; &nbsp;<a
					href='news.php'>Новости</a>
			</div>
			<div class="bread-title">
				<div class="bread-title_text">Новости</div>
				<div class="bread-title_line"></div>
			</div>
			<div class="news-content">
				<div class="news-content-items">
					<div class="news-content-item">
						<div class="news-content-img"><img src="img/news/01.jpg" alt=""></div>
						<a href='' class="news-content-name">Дни рождения</a>
						<div class="news-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
					<div class="news-content-item">
						<div class="news-content-img"><img src="img/news/02.jpg" alt=""></div>
						<a href='' class="news-content-name">Массаж</a>
						<div class="news-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
					<div class="news-content-item">
						<div class="news-content-img"><img src="img/news/03.jpg" alt=""></div>
						<a href='' class="news-content-name">Личный водитель</a>
						<div class="news-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
					<div class="news-content-item">
						<div class="news-content-img"><img src="img/news/04.jpg" alt=""></div>
						<a href='' class="news-content-name">Лекционный зал</a>
						<div class="news-content-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.
							Quidem quo vero a, cumque culpa aliquam nostrum. </div>
					</div>
					
				</div>
			</div>
		</div>
	</div>
</div>

<? include('footer.php'); ?>